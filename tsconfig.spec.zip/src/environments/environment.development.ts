export const environment = {
    URLApi:"http://localhost:8080/v1/"
};
