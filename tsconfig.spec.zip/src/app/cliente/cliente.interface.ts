import { UUID } from "crypto";

export interface Cliente {
    idCliente:UUID;
    nombre:String;
    apellidos:String;
    tipoDocIdentidad:UUID;
    numeroDocumento:String;
    direccion:String;
    correo:String;
    telefono:String;
    fechaNacimiento:Date;
    usuarioId:UUID;
    fechaRegistro:Date;
}