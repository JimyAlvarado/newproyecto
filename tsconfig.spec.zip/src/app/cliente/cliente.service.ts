import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { constants } from '../constantes'
import { catchError } from 'rxjs/operators';
import { Cliente } from './cliente.interface';
import { UUID } from 'crypto';
@Injectable({
  providedIn: 'root'
})
export class ClienteService {
  private api=environment.URLApi+'/cliente/';
  constructor(private httpClient: HttpClient){}
  search(): Observable<any> {  
    return this.httpClient.get(this.api + 'listar/')
    .pipe(catchError(constants.errorHandler))
  }
  create(data:Cliente): Observable<any> {  
    return this.httpClient.post(this.api + 'guardar/', JSON.stringify(data), constants.httpOptions)
    .pipe(
      catchError(constants.errorHandler)
    )
  } 

  update(data:Cliente,id:UUID): Observable<any> {  
    return this.httpClient.put(this.api + 'actualizar/'+id, JSON.stringify(data), 
    constants.httpOptions)
    .pipe(
      catchError(constants.errorHandler)
    )
  } 

  delete(id:UUID): Observable<any> {  
    return this.httpClient.delete(this.api + 'eliminar/'+id)
    .pipe(
      catchError(constants.errorHandler)
    )
  }
}