import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ClienteService } from '../cliente.service';
import { Cliente } from '../cliente.interface';
import { UUID } from 'crypto';

@Component({
  selector: 'app-view',
  standalone: true,
  imports: [CommonModule,RouterModule],
  templateUrl: './view.component.html',
  styleUrl: './view.component.css'
})
export class ViewClienteComponent {
  data: Cliente[] = [];
  constructor(public service: ClienteService) { }

  ngOnInit(): void {
    //this.search();   
  }
  search(){
    this.service.search().subscribe((data: Cliente[])=>{
      this.data = data;
      console.log(this.data);
    }) 
  }
  delete(id:UUID){
    this.service.delete(id).subscribe(res => {
      this.search();  
    })
  }



}
