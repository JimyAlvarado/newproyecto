import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
let isLogin=false;

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  templateUrl: isLogin?'./app.component1.html':'./app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'sistemaclase';
}
