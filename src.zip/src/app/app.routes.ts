import { Routes } from '@angular/router';
import { ViewClienteComponent } from './cliente/view/view.component';
import { FormClienteComponent } from './cliente/form/form.component';

export const routes: Routes = [
    {path:"cliente",component:ViewClienteComponent},
    {path:"cliente/create",component:FormClienteComponent},
    {path:"cliente/edit/:idcliente",component:FormClienteComponent}
];
