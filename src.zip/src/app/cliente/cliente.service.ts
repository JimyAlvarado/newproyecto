import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '../../environments/environment';
import { constants } from '../constantes'
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ClienteService {
  constructor(private httpClient: HttpClient){}

 /* Methodo para leer datos */
  search(): Observable<any> {  
    return this.httpClient.get(environment.URLApi + '/posts/')
    .pipe(catchError(this.errorHandler))
  }


}
