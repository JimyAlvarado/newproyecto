export interface Cliente {
    idCliente:any;
    nombre:string;
    apellidos:string;
    tipoDocIdentidad:any;
    numeroDocumento:string;
    direccion:string;
    correo:string;
    telefono:string;
    fechaNacimiento:Date;
    usuarioId:any;
    fechaRegistro:Date;
}